package abmc;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.PreparedStatement;

public class Alumno  {
    private String nombre;
    private int edad;

    public Alumno() {}

    public Alumno(String nombre, int edad) {
        this.setNombre(nombre);
        this.setEdad(edad);
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    @Override
    public String toString() {
        return "nombre=" + nombre + ", edad=" + edad;
    }
    
    //metodos ABMC
    public static void consultarTodos() throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        //creo una conexion a la BD
        Connection unaConexion = Conexion.obtenerConexion();
        
        //armo la consulta sql
        String consulta = "select * from alumnos";
        
        //creo una sentencia
        Statement unaSentencia = unaConexion.createStatement();
        
        //ejecuto la sentencia y guardo el resultado
        //en un objeto de tipo ResultSet
        ResultSet unResultado = unaSentencia.executeQuery(consulta);
        
        //recorro y muestro el resultado con un bucle 
        while (unResultado.next()) 
        {
            System.out.println("Nombre: " + unResultado.getString("nombre"));
            System.out.println("Edad: " + unResultado.getInt("edad"));
            System.out.println("--------------------------------");
        }
        
        //cierro la sentencia y la conexion
        unaSentencia.close();
        unaConexion.close();
    }
    
    public static void consultarUno(String nombre) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        //creo una conexion a la BD
        Connection unaConexion = Conexion.obtenerConexion();
        
        //armo la consulta sql
        String consulta = "select * from alumnos where nombre = '" + nombre + "'";
        
        //creo una sentencia
        Statement unaSentencia = unaConexion.createStatement();
        
        //ejecuto la sentencia y guardo el resultado
        //en un objeto de tipo ResultSet
        ResultSet unResultado = unaSentencia.executeQuery(consulta);
        
        //recorro y muestro el resultado con un bucle 
        if (unResultado.next()) 
        {
            System.out.println("Nombre: " + unResultado.getString("nombre"));
            System.out.println("Edad: " + unResultado.getInt("edad"));
            System.out.println("--------------------------------");
        }
        
        //cierro la sentencia y la conexion
        unaSentencia.close();
        unaConexion.close();
    }
    
    public static void insertar(Alumno a) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        //creo una conexion a la BD
        Connection unaConexion = Conexion.obtenerConexion();
        
        //armo la sentencia sql
        String insercion = "insert into alumnos values(?,?)";
        
        //creo una sentencia
        PreparedStatement unaSentencia = unaConexion.prepareStatement(insercion);
        
        unaSentencia.setString(1, a.getNombre());
        unaSentencia.setInt(2, a.getEdad());
        
        //ejecuto la sentencia
        unaSentencia.execute();
        
        //cierro la sentencia y la conexion
        unaSentencia.close();
        unaConexion.close();
    }
    
    
    public static void actualizar(Alumno a) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        //creo una conexion a la BD
        Connection unaConexion = Conexion.obtenerConexion();
        
        //armo la sentencia sql
        String actualizacion = "update alumnos set edad = ? where nombre = ?";
        
        //creo una sentencia
        PreparedStatement unaSentencia = unaConexion.prepareStatement(actualizacion);
        
        unaSentencia.setInt(1, a.getEdad());
        unaSentencia.setString(2, a.getNombre());
        
        //ejecuto la sentencia
        unaSentencia.execute();
        
        //cierro la sentencia y la conexion
        unaSentencia.close();
        unaConexion.close();
    }
    //*

    /**
     *
     * @param nombre
     * @throws ClassNotFoundException
     * @throws InstantiationException
     * @throws IllegalAccessException
     * @throws SQLException
     */
    
    public static void eliminar(String nombre) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        //creo una conexion a la BD
        Connection unaConexion = Conexion.obtenerConexion();
        
        //armo la sentencia sql
        String eliminacion = "delete from alumnos where nombre = ?";
        
        //creo una sentencia
        PreparedStatement unaSentencia = unaConexion.prepareStatement(eliminacion);
        
        unaSentencia.setString(1, nombre);
        
        //ejecuto la sentencia
        unaSentencia.execute();
        
        //cierro la sentencia y la conexion
        unaSentencia.close();
        
        
        unaConexion.close();
    }
    
    
}
