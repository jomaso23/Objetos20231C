create database colegio;

use colegio;

create table alumnos(nombre varchar(20), edad int);

insert into alumnos values('Juan',25),('Maria',30),
('Luis',20),('Ana',40);

select * from alumnos;

