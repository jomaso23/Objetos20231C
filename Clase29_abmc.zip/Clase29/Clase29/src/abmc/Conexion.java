package abmc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {
    public static Connection obtenerConexion() throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        //defino el driver a usar para conectar java 
        //con mysql
        String driver = "com.mysql.cj.jdbc.Driver";
        
        //defino la cadena de conexion
        String cadena = "jdbc:mysql://127.0.0.1:3306/colegio";
        
        //usuario y contraseña
        String usuario = "root";
        
        String clave = "";
        
        //creo un objeto de tipo Driver por API Reflection
        Class.forName(driver).newInstance();
        
        //retorno el objeto de conexion
        return DriverManager.getConnection(cadena, usuario, clave);
    }
    
}
